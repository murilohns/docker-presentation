<?php
	require("../pagarme-php/Pagarme.php");

    Pagarme::setApiKey("ak_test_9c0AUwmQm9EAcMTGM3zRd5y6GzfuWo");

    $customer = $_POST['customer'];
    $card_hash = $_POST['card_hash'] || $_POST['pagarme']['card_hash'];

    if(isset($card_hash)){
        $card_hash = $_POST['card_hash'];

        $plan = PagarMe_Plan::findById("247829"); //encontra um plano

        $subscription = new PagarMe_Subscription(array(
            "plan" => $plan, //cria uma assinatura no plano encontrado
            "card_hash" => $card_hash,
            'customer' => array(
                'email' => 'api@test.com',
                'document_number' => '07844221259'
            )));

        $subscription->create();
    }else{
        $token = $_POST['token'] || $_POST['pagarme']['token'];
        $amount = $_POST['pagarme']['amount'] || $_POST['amount'];

        $transaction = PagarMe_Transaction::findById($token);

        $transaction->capture($amount); 
    }
	
?>
